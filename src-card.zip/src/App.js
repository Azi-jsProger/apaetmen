import './App.css';
import {useEffect, useState} from "react";
import Card from "./components/card/card";
import Loading from "./components/loading/loading";

function App() {

    const [apartmen , setApartmen] = useState([])
    const [isLoading    , setIsLoading] = useState(false)
    async function getApartmen() {
        setIsLoading(true)
        try {
            const response = await fetch(' https://realty-ggcv.onrender.com/main/flats/')
            const data = await response.json()
            setApartmen(data.results)
        } catch (e) {
            console.log(e)
        } finally {
            setIsLoading(false)
        }
    }

    useEffect(() => {
        getApartmen()
    }, []);




  return (
      <div>
          {isLoading ?
              <Loading></Loading>
           :
          <div className="App">
              {apartmen.map((item, idx, array) => {

                  return (
                      <Card
                          key={idx}
                          title={item.title}
                          images={item.flat_images}
                          price={item.price}
                          rooms={item.rooms}
                          square={item.total_area}
                          floor={item.floor}
                          maxfloor={item.number_of_floors}
                      />
                  )

              })}
          </div>
          }
      </div>




  );
}

export default App;












