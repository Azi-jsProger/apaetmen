import React from 'react';
import './style.css'



const Card = (props) => {

    const {
        title ,
        images,
        price,
        rooms,
        square,
        floor,
        maxfloor
    } = props



    return (
            <div className='card'>
                        <div>
                            {images.length > 0 && (
                                <img
                                    className='images'
                                    src={images[0].image}
                                    alt="First Image"
                                />
                            )}

                        </div>

                            <div className='block'>

                                <div>
                                    <h1 className='apartmen-h  discription-hover'>{title}</h1>

                                    <div className='row'>
                                        <span
                                            className='discription-size discription-hover '>Кол-во комнат: {rooms}</span>
                                        <span className='discription-size discription-hover'>Площадь: {square}м²</span>
                                        <span className='discription-size discription-hover'>Этаж: {floor}</span>
                                    </div>

                                        <h4 className='geo discription-hover'>г. Бишкек, Кыргызстан</h4>

                                    <div className='row space'>
                                    <h1 className='price-apartmen'>${price}</h1>
                                        <button className='button-card'>Посмотреть детали</button>
                                    </div>

                                </div>


                            </div>

            </div>
    );
};

export default Card;