import React from 'react';
import './style.css'
const Footer = () => {
    return (
        <div className='footer'>
            FOOTER
        </div>
    );
};

export default Footer;