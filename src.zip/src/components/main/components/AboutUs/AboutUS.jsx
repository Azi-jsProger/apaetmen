import React from 'react';
import './style.css'


const AboutUs = () => {
    return (
        <div className='abo'>
        ABOUTUS
        </div>
    );
};

export default AboutUs;