import React from 'react';
import './style.css'

const Contacts = () => {
    return (
        <div className='con'>
        CONTACTS
        </div>
    );
};

export default Contacts;