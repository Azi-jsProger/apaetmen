import './App.css';
import {useEffect, useState} from "react";
import enot from '../src/enot.gif'

function App() {

    const [apartmen , setApartmen] = useState([])
    const [isLoading    , setIsLoading] = useState(false)
    async function getApartmen() {
        setIsLoading(true)
        try {
            const response = await fetch(' https://realty-ggcv.onrender.com/main/flats/')
            const data = await response.json()
            setApartmen(data.results)
        } catch (e) {
            console.log(e)
        } finally {
            setIsLoading(false)
        }
    }

    useEffect(() => {
        getApartmen()
    }, []);
  return (
    <div className="App">
        {isLoading ?
            <div className='Loading-flex'>
                <div className='Loading'>
                    <img className='enot-img' src={enot} alt=""/>
                </div>
            </div>

            :
            <div>
                {apartmen.map((item, idx, array) => {
                    return (
                        <div
                            className='apartmen'
                            key={idx}
                        >
                            {item.flat_images.length > 0 && (
                                <img
                                    className='apartmen-img'
                                    src={item.flat_images[0].image}
                                    alt="First Image"
                                />
                            )}

                            <div className='block'>
                                <div>
                                    <div className='apartmen-h  h-hover'>{item.title}</div>

                                    <div className='row'>
                                        <div className='apartmen-cart h-hover'>Кол-во комнат: {item.rooms}</div>
                                        <div className='apartmen-cart h-hover'>Площадь: {item.total_area}м²</div>
                                        <div className='apartmen-cart h-hover'>Этаж: {item.floor}</div>
                                    </div>

                                    <h4 className='geo h-hover'>г. Бишкек, Кыргызстан</h4>
                                </div>


                                <div className='row space'>
                                    <div className='apartmen-dollar'>${item.price}</div>
                                    <button className='button'>Посмотреть детали</button>
                                </div>

                            </div>


                        </div>
                    )
                })}
            </div>
        }


    </div>
  );
}

export default App;












